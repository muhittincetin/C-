# OTEL OTOMASYON GORSELLER
## *ANA MENU*
![ana menu](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/ana%20menu.PNG)
## *ANA MENU 1. SECENEK*
![ana menu1](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/1in1.PNG)
## *ANA MENU 2. SECENEK*
![ana menu2](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/1in2.PNG)
## *ANA MENU 3. SECENEK*
![ana menu3](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/1in3.PNG)
## *ODA EKLEME*
![otel uygulaması](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/Capture.PNG)
![otel uygulaması](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/Capture1.PNG)
## *ODA LİSTELEME*
![otel uygulaması](https://github.com/MelihGuler/otelOtomasyon-withCpp/blob/master/gorseller/Capture2.PNG)
### Aynı Şekilde Müşteri Ekleme, Silme ve Görüntüleme Özellikleri de Programda Mevcuttur.
